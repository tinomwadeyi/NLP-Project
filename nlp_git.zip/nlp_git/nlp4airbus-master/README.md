Welcome to nlp4airbus
=====================

nlp4airbus v 0.1.5, 

This package aims at providing a common set of tools to perform some
simple processing on Airbus technical texts (i.e texts where information is almost represented in the technical terms)

It features:

-   regular expressions to retrieve entities (part numbers, maintnenace
    tasks... `nlp4airbus.re.entity`) or clean the text (SAP tags...
    `nlp4airbus.re.clean`)
-   stemmers for all four languages (nlp4airbus.utils.stem) with
    support for Airbus Acronyms from Lexinet
    (`nlp4airbus.utils.lexinet`)
-   fast string substitution (`nlp4airbus.utils.substitution`)
-   dictionaries of Airbus vocabulary,
-   methods to build a list of stopWords 
    (`nlp4airbus.utils.stopwords`)
-   Airbus glossaries, where each glossary is supposed to be a closed list (even if not exhaustively provided, e.g. maintenance activities)
    (`nlp4airbus.index_keys_extraction.linguistic_resources`)
-   linguistic resources (stop words or anti-dictionary of non informative words e.g. `a, an, the, airbus...`)    
    (`nlp4airbus.utils.stopwords`). Some of them have to be managed depending of the project objective.
-   word and document embeddings
    ([Word2vec](https://radimrehurek.com/gensim/models/word2vec.html),
    [Doc2vec](https://radimrehurek.com/gensim/models/doc2vec.html),
    [FastText](https://radimrehurek.com/gensim/models/fasttext.html))
    for Airbus text objetcts.
    pretrained models will be provided in a future version.

It is meant to be a standalone Python package but it is build so that it
can be used on [Skywise](https://core.skywise.com/). So it is built on
minimal set of dependencies as Skywise cannot access the web and thus
packages that can only be installed through `pip` are not available.

The word and document embeddings are directly trained on the Skywise
platform. The model parameters are dumped on dummy datasets and because
of the size only available there.

Main features of this release
=============================
To adress use cases with multiple textual sources linking, dedicated functionalities have been implemented, that are not following classical preprocessing such as:
1. Lower case all words and clear texts from punctuation
2. Remove stopwords
3. Remove words with a length below 4 characters
4. Lemmatize words
5. Remove words with a length below 3 characters (again, as for example 'doing' will now be 'do' after step 4)
6. Create bigrams
7. Prune the dictionary from high frequency words (words that occur in over 95% of the documents) and then prune the texts by excluding those words from the text

Instead, we support advanced indexing of technical terms:
1. Correct obvious english mistakes if relevant. Especially if lexical variants or mistake of a very common term are considered as discriminant terms, it would impact
how the related document will be classified. Noise is generally at a high cost if not filtered out at early stage of a NLP pipeline.
2. create bigrams from the result of named entities or noun phrases extraction, depending of the most suitable approach for 
a corpora, specific segments of this corpora (e.g. titles) or part of an heterogeneous corpora. 
By this way, we can address and tackle situations where technical publications in 'good' english are mixed with less well written textual feedbacks.
3. Once bigrams have been acquired, filter out the ones that have stopwords or frontier word in them. It raise the chance to get meaningfull technical key index at the end.
4. Then, it is relevant to create new bigrams for all considered texts from all the candidate terms identified during previous phases.
5. Eventually, use Pointwise Mutual information (PMI) to identify words that should better be considered within a ngram, 
given that PMI is high when probability of co-occurrence is only slightly lower than the probabilities of occurrence of each word

To improve previous result it is then possible to extract lexical variants of bigrams based on distance metrics that are less noisy due to the presence of two words.
This bigram context discriminate the candidates (by the left or right context) and avoid lot of hasardous proximity between strings of one word. 
Substitution of these bigrams improve consistency of the index that will be considered by machine learning algorithms to compute similarity, clusters, distribution of topics in a text a so on.

Validation and management of the extracted variants is also plus to enable end user to inform the application based on the resulting index and force the application to not reproduce observed errors.

As a simple illustration, we implement Latent Semantic Indexing topic models and K-means methods to provide a similarity metric between one document and several others while 
beeing able to :
- indicate how the similar documents belong to different clusters (when taking into account all words instead of only the technical terms)
- indicate what is the distribution of topics between two documents. by this way if one long document that express several topics is considered as very similar to a smaller one that share one topics, an indicating of their 
difference in terms of all potential topics can be shown.


Dependencies
============

Many part of this package rely on

-   [NumPy](http://www.numpy.org/)
-   [scikit-learn](http://scikit-learn.org/stable/)
-   [pandas](https://pandas.pydata.org/)
-   [nltk](https://www.nltk.org/)
-   [langdetect](https://github.com/Mimino666/langdetect)

Optional:

-   [gensim](https://radimrehurek.com/gensim/index.html) for embeddings
-   [flashtext](https://github.com/vi3k6i5/flashtext) for substitution.
    A dump is available in nlp4airbus.external.flashtext.

They are not all necessary at once. It is specified in each module
documentation.

Access to the package on Airbus LAN
===================================

Add the following path to your `$PYTHONPATH` environment variable or to
`sys.path`:

-   On Windows:
    `\\sfs.corp\Organization\CORPO-SECRETARY\Z\Analytics Accelerator\Team\fred\nlp4airbus\src`
-   On Mac:
    `/Volumes/Organization/CORPO-SECRETARY/Z/Analytics Accelerator/Team/fred/nlp4airbus/src`

Access to the package on Skywise/Foundry
========================================

It is available through Code Workbook and Python Transforms.

Python Transforms
-----------------

Add `nlp4airbus` as a *run* requirement in the `conda_recipe/meta.yaml`
file together with `gensim` and `nltk`. Please use `nltk-with-data` to
get access to nltk data packages such as corpus or stemmers.

Code Workbook
-------------

Change the Code workbook environment in the
`Customize Spark environment` menu.

Documentation and examples
==========================

Documentation is accessible at [GitHub Pages](https://gheprivate.intra.corp/pages/SICOT-F/nlp4airbus/html/index.html).

Documentation is generated with [Sphinx](http://www.sphinx-doc.org).
Please use the [reST
syntax](http://www.sphinx-doc.org/en/master/usage/restructuredtext/basics.html)
in function and class docstrings (which is the default in Pycharm):

    def function(param1, param2):
       """
       This is a reST style docstring.

       :param param1: this is a first param
       :type param1: type a first param
       :param param2: this is a second param
       :type param2: type of second param
       :returns: this is a description of what is returned
       :rtype: return type
       :raises keyError: raises an exception
       """

The documentation is in the `docs` folder (same level as `src`). You can
build `html` page with:

    > cd docs
    > sphinx-apidoc -f -o source/ ../src/nlp4airbus/
    > make html

Notebook examples can be found in the `examples` sub-folder of the
package.

Source and publishing to Skywise
================================

The main git repo is accessible on [GitHub Enterprise
(ghe)](https://gheprivate.intra.corp/SICOT-F/nlp4airbus). This is the
one to use for development.

There is a second repo on
[Foundry](https://core.skywise.com/workspace/code/repos/ri.stemma.main.repository.57ff9886-8f65-41ec-8bc6-6255ddaa15b3/contents/refs%2Fheads%2Fmaster/conda_recipe/meta.yaml)
for publishing the library on the Skywise platform.

It is not recommended to use the Foundry Authoring UI for 2 reasons:

1.  Although Skywise is the platform where the package will be most
    used, it is meant to be a standalone regular package. It is better
    to use more powerful tools and editors on own computer than a
    browser editor.
2.  Library publishing on Skywise requires to tag (as Git tag) a commit
    with a revision number. Authoring UI does not allow to tag commits.
    Therefore the repository must be cloned elsewhere, tagged and pushed
    back to Foundry.

The repository is only replicated to
[Foundry](https://core.skywise.com/workspace/code/repos/ri.stemma.main.repository.57ff9886-8f65-41ec-8bc6-6255ddaa15b3/contents/refs%2Fheads%2Fmaster/conda_recipe/meta.yaml)
when a version of the module is released. Therefore I have two remotes
on my `.git/config`,a default `ghe` for daily work and a `skywise`rmeote
for publishing:

    $ git remote -v
    ghe  https://gheprivate.intra.corp/SICOT-F/nlp4airbus.git (fetch)
    ghe  https://gheprivate.intra.corp/SICOT-F/nlp4airbus.git (push)
    skywise  https://<login>:<token>@core.skywise.com/stemma/git/ri.stemma.main.repository.57ff9886-8f65-41ec-8bc6-6255ddaa15b3/nlp4airbus (fetch)
    skywise  https://<login>:<token>@core.skywise.com/stemma/git/ri.stemma.main.repository.57ff9886-8f65-41ec-8bc6-6255ddaa15b3/nlp4airbus (push)

Skywise publishing requires to tag before pushing:

    > git tag x.y.z
    > git push skywise master --tags

Coding style
============

Please follow [PEP-8](https://www.python.org/dev/peps/pep-0008/) coding
style and [PEP-287](https://www.python.org/dev/peps/pep-0287/) for
docstrings.

Unit tests
==========

It is recommended to put unit testing in docstrings with the `>>>`
syntax:

    def stem_single_word(self, word):
        """
        Stem a single word

        :param word: token to stem
        :type word: str
        :return: stemmed word
        :rtype: str

        >>> from nlp4airbus.utils.stem import Stem
        >>> s = Stem()
        >>> s.stem_single_word('Brakes')
        'brake'
        >>> s.stem_single_word('ACMS')
        'ACMS'
        """

Then you can run tests from the `docs` folder:

    > cd docs
    > make doctest


# Publishing Conda Libraries

This repository template is setup to publish a Python package into Foundry.

By default, the repository name at the time of the bootstrap is used as the name of the conda package.
To override this, modify the ``condaPackageName`` variable in the ``gradle.properties`` file. You will have to tick
the "Show hidden files" checkbox located in the bottom left of the Authoring interface.
 
The ``build.gradle`` file configures the publish task to only run when the repository is tagged. 
If Authoring version is 2.17.0+, you can create tag in "Branches" tab. Otherwise, you 
will need to clone the repository, run ``git tag x.y.z``, and then push the tags with ``git push --tags``.

By publishing a library to a particular channel, your repository will acquire ownership over the name of that library.
This means that if another repository tries to publish a library of the same name to the same channel, it will be rejected.
This is done to prevent conflicts.

## Consuming Conda Libraries

To make use of this library in a Python Transforms project, you must add the appropriate channel. The channel name
defaults to ``libs`` and we recommend not changing this. If you do not change it, then you can consume this channel
in another project by adding the following to your Python Transforms project's ``transforms-python/build.gradle``:

```
apply plugin: 'com.palantir.transforms.lang.python'
apply plugin: 'com.palantir.transforms.lang.python-defaults'

transformsPython {
  sharedChannels "libs"
}
```

You can then depend on the name of the library as usual in the project's ``conda_recipe/meta.yaml`` file:

```
requirements:
  run:
    python
    my_library
```

You will also need to specify additional capabilities in your ``ci.yml`` file: 

```
required-job-token-capabilities:
  - transforms
  - python-library
```

Adding library to your project will install packages from source directory. The source directory defaults to ``src/``
and we recommend not changing this. You still need to import package before you can use it in your module. Be aware that you have to import package name and not library name (in this template, package name is ``myproject``).

### Import example

Let's say your library structure is:

```
conda_recipe/
src/
  examplepkg/
    mymodule.py
  otherpkg/
    utils.py
  setup.cfg
  setup.py
```

And in ``gradle.properties``, value of ``condaPackageName`` is ``mylibrary``.

When consuming library, your ``conda_recipe/meta.yaml`` should contain:

```
requirements:
  run:
    ...
    mylibrary
```

Than you can import any of the packages ``examplepkg`` or ``otherpkg``.

```
import examplepkg as E
from examplepkg import mymodule
from otherpkg.utils import some_function_in_utils
```
