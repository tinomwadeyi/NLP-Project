---
name: Code Workbook Template
about: Report bugs in Skywise CW templates

---

**What is the buggy template?**
[nlp4airbus] buggy tempalte

**Describe the problem**

**Path to the code workbook:**
https://core.skywise.com/workspace/vector/view/ri.arrow.main.workbook.858c279b-86ce-47ae-b50d-eec033

**Copy/Paste log message:**
paste from message log
