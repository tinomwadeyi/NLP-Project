nlp4airbus\.lang package
========================

Subpackages
-----------

.. toctree::

    nlp4airbus.lang.en

Module contents
---------------

.. automodule:: nlp4airbus.lang
    :members:
    :undoc-members:
    :show-inheritance:
