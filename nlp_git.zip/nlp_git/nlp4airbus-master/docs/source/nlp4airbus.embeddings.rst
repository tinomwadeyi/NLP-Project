nlp4airbus\.embeddings package
==============================

Submodules
----------

nlp4airbus\.embeddings\.doc2vec module
--------------------------------------

.. automodule:: nlp4airbus.embeddings.doc2vec
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.embeddings\.word2vec module
---------------------------------------

.. automodule:: nlp4airbus.embeddings.word2vec
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nlp4airbus.embeddings
    :members:
    :undoc-members:
    :show-inheritance:
