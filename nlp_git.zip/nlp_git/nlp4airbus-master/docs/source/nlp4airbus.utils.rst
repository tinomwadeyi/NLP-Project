nlp4airbus\.utils package
=========================

Submodules
----------

nlp4airbus\.utils\.cooccurence module
-------------------------------------

.. automodule:: nlp4airbus.utils.cooccurence
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.distances module
-----------------------------------

.. automodule:: nlp4airbus.utils.distances
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.encoding module
----------------------------------

.. automodule:: nlp4airbus.utils.encoding
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.lexinet module
---------------------------------

.. automodule:: nlp4airbus.utils.lexinet
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.ngrams module
--------------------------------

.. automodule:: nlp4airbus.utils.ngrams
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.plot\_utils module
-------------------------------------

.. automodule:: nlp4airbus.utils.plot_utils
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.stem module
------------------------------

.. automodule:: nlp4airbus.utils.stem
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.stopwords module
-----------------------------------

.. automodule:: nlp4airbus.utils.stopwords
    :members:
    :undoc-members:
    :show-inheritance:

nlp4airbus\.utils\.substitution module
--------------------------------------

.. automodule:: nlp4airbus.utils.substitution
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nlp4airbus.utils
    :members:
    :undoc-members:
    :show-inheritance:
