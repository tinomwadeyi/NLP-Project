nlp4airbus\.external package
============================

Submodules
----------

nlp4airbus\.external\.flashtext module
--------------------------------------

.. automodule:: nlp4airbus.external.flashtext
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nlp4airbus.external
    :members:
    :undoc-members:
    :show-inheritance:
