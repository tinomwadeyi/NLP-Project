nlp4airbus\.lang\.en package
============================

Submodules
----------

nlp4airbus\.lang\.en\.inflection module
---------------------------------------

.. automodule:: nlp4airbus.lang.en.inflection
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nlp4airbus.lang.en
    :members:
    :undoc-members:
    :show-inheritance:
