import matplotlib.pyplot as plt
from wordcloud import WordCloud

cmap = plt.get_cmap('Blues')

font_path = "./OpenSans-CondBold.ttf"

d = {'nlp4airbus': 150,
     'Quality': 35,
     'Engineering': 25,
     'Procurement': 22,
     'Concession': 14,
     'TLB': 8,
     'Manufacturing': 29,
     'tags': 8,
     'Entity': 12,
     'text': 17,
     'Classification': 23,
     'FAL': 12,
     'Work order': 13,
     'PFR': 9,
     'logbook': 12,
     'Clustering': 16,
     'Dictionary': 14,
     'regex': 8,
     'MAP': 11,
     'OI': 7,
     'QSR': 9,
     'Keywords': 13,
     'cooccurence': 11,
     'Tokens': 15,
     'Word2vec': 16,
     'Embeddings': 18,
     'TF-IDF': 17,
     'Stemming': 14,
     'Substitution': 17,
     'Analysis': 6,
     'n-grams': 7,
     'recognition': 5,
     'Bag of words': 6,
     'report': 7,
     'manual': 9}

text2generate = ' '.join([(k + ' ') * v for k, v in d.items()])
print(text2generate)
d = {k: float(v) for k, v in d.items()}

wc = WordCloud(font_path=font_path, mode="RGBA", background_color=None, relative_scaling=0.7,
               max_font_size=300, random_state=42, width=1200, height=600, prefer_horizontal=0.1)
wc.generate_from_frequencies(d)


def color_func(word, font_size, position, orientation, random_state=None, **kwargs):
    return cmap(((float(font_size) / float(wc.layout_[0][1])) + 0.3) / 1.3, bytes=True)


wc.recolor(color_func=color_func, random_state=3)
wc.to_file('logo.png')

# plt.imshow(wordcloud, interpolation='bilinear')
# plt.axis("off")
# plt.savefig('logo.png')
